package week1.day1;

public class Vehicle {

	public static void main(String[] args) {
		
		   int noofwheels = 2;
		   String brand = "bajaj";
		   char logo = 'B';
		   double kms = 15656.42;
		   long mobileno = 1234567890l;
		   float milege = 30.6f;
		   
		   System.out.println("noofwheels = " + noofwheels + brand + logo);
		   System.out.println("brand name is " +brand);
	       System.out.println(logo);
	       System.out.println(kms);
	       System.out.println(mobileno);
	       System.out.println(milege);
	}

}
