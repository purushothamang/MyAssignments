package week1.day1;

public class Home {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String homename = "Happy family";
		char name = 'H';
		int Rooms = 2;
		float roomlength = 12.56f;
		long adress = 123456l;
	
				
		System.out.println(homename);
		System.out.println(name);
		System.out.println(Rooms);
		System.out.println(roomlength);
		System.out.println(adress);
		

	}

}
