package week1.day1;

public class Fibonocci {

	public static void main(String[] args) {
		
		
	int firstnumber =0;
	int secondnumber =1;
	int sum = 0;
	
	
	System.out.println(firstnumber);
	System.out.println(secondnumber);
	
	for (int i=0;i <=11; i++)
	{
		sum = firstnumber + secondnumber;
		firstnumber = secondnumber;
		secondnumber = sum;
		System.out.println(sum);
	}
	
	

	}

}
