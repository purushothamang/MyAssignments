package week1.day1;

import org.apache.commons.io.FileSystemUtils;

public class Oddno {

	public static void main(String[] args) {
		int n = 10;
		for (int i=1;i<=10;i++) {
			if (i%2!=0)	
			System.out.println(i);
		}
	

	}

}
