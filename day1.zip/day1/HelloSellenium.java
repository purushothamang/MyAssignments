package week1.day1;

public class HelloSellenium {

	public static void main(String[] args) {
	
   
   System.out.println("noofwheels");
 
	}

}
